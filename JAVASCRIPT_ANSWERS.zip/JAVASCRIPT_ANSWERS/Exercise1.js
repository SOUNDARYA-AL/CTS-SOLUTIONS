JavaScript Basics & Setup

<!-- In HTML -->
<script src="main.js"></script>



// main.js
console.log("Welcome to the Community Portal");

window.onload = () => {
  alert("Page is fully loaded!");
};