Decompile a Class File:

java -jar cfr.jar Hello.class
