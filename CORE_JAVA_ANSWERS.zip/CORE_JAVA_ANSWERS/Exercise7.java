Type Casting Example:


public class Casting {
    public static void main(String[] args) {
        double d = 9.8;
        int i = (int) d;
        int j = 10;
        double x = (double) j;
        System.out.println(i + " " + x);
    }
}