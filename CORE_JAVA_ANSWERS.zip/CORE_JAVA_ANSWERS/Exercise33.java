Transaction Handling in JDBC:

c.setAutoCommit(false); // Execute operations, then c.commit(); or c.rollback();
