Data Type Demonstration:


public class DataTypes {
    public static void main(String[] args) {
        int i = 1;
        float f = 2.5f;
        double d = 3.14;
        char c = 'A';
        boolean b = true;
        System.out.println(i + " " + f + " " + d + " " + c + " " + b);
    }
}