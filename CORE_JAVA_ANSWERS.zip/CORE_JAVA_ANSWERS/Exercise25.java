HashMap Example:

import java.util.*; public class MapExample { public static void main(String[] args) { HashMap<Integer, String> map = new HashMap<>(); map.put(1, "Alice"); System.out.println(map.get(1)); } }
