Virtual Threads (Java 21):

Thread.startVirtualThread(() -> System.out.println("Hello from virtual thread"));
