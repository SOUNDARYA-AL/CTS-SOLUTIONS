Using javap:

javac Hello.java && javap -c Hello
