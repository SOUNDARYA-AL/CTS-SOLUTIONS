TCP Client-Server Chat:

ServerSocket server = new ServerSocket(1234); Socket client = server.accept(); // Input/output stream setup follows

