Syntax, Data Types, and Operators:

const eventName = "Community Meetup";
const eventDate = "2025-07-01";
let seats = 50;

console.log(`${eventName} is on ${eventDate}. Available seats: ${seats}`);

seats--; // After one registration